import 'adaptive_plan.dart';

class BehaviorDashboard {
  final int riskScore;
  final List<String> riskyTriggers;
  final List<String> riskyHours;
  final DateTime? lastSurveyDate;
  final DateTime? lastBreathDate;
  final String breathTrend;

  /// 'improving'/'worsening'/'stable' over the last 3 breath tests (see
  /// [BreathTestEngine.analyzeTrend]) — a tighter, more responsive rolling
  /// signal than [breathTrend] above, which only compares the very first
  /// test ever taken against the latest one.
  final String breathTrendLast3;
  final int breathTrendRiskAdjustment;
  final String progressSummary;
  final List<String> todaysTasks;
  final List<String> coachCommands;
  final Map<String, double> commandSuccessScores;
  final Map<String, double> commandCategoryScores;
  final String commandMixMode;
  final int weeklySurveyRiskScore;
  final String weeklySurveyRiskLevel;
  final List<String> weeklyTopRiskDrivers;
  final List<String> riskExplanation;
  final Map<String, double> learnedWeights;
  final String predictedRiskWindow;
  final int predictionConfidence;
  final String predictedTrigger;
  final AdaptivePlan plan;

  const BehaviorDashboard({
    required this.riskScore,
    required this.riskyTriggers,
    required this.riskyHours,
    this.lastSurveyDate,
    this.lastBreathDate,
    required this.breathTrend,
    this.breathTrendLast3 = 'stable',
    this.breathTrendRiskAdjustment = 0,
    required this.progressSummary,
    required this.todaysTasks,
    required this.coachCommands,
    required this.commandSuccessScores,
    required this.commandCategoryScores,
    required this.commandMixMode,
    required this.weeklySurveyRiskScore,
    required this.weeklySurveyRiskLevel,
    required this.weeklyTopRiskDrivers,
    required this.riskExplanation,
    required this.learnedWeights,
    required this.predictedRiskWindow,
    required this.predictionConfidence,
    required this.predictedTrigger,
    required this.plan,
  });
}
