import 'dart:async';
// ignore_for_file: use_build_context_synchronously

import 'dart:convert';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest_all.dart' as tz;
import 'package:timezone/timezone.dart' as tz;

import '../core/app_texts.dart';
import '../models/adaptive_task_models.dart';
import '../models/medication.dart';
import '../models/snoring_probe_event.dart';
import '../models/task_assignment.dart';
import '../pages/breath_test_page.dart';
import '../pages/craving_sos_page.dart';
import '../pages/self_challenge_page.dart';
import '../pages/sleep_routine_page.dart';
import '../pages/task_smoked_confirm_page.dart';
import '../pages/weekly_survey_page.dart';
import '../widgets/quick_action_menu.dart';
import 'android_watchdog_service.dart';
import 'language_service.dart';
import 'notification_budget.dart';
import 'phone_state_service.dart';
import 'sleep_probe_service.dart';
import 'smoked_log_button_service.dart';
import 'storage_service.dart';
import 'task_assignment_service.dart';

@pragma('vm:entry-point')
void notificationTapBackground(NotificationResponse response) {
  NotificationService.handleBackgroundNotificationResponse(response);
}

class NotificationService {
  static final FlutterLocalNotificationsPlugin _plugin =
      FlutterLocalNotificationsPlugin();
  static final StreamController<Map<String, String>> _taskActionController =
      StreamController<Map<String, String>>.broadcast();
  static GlobalKey<NavigatorState>? _navigatorKey;

  static const String _typeBreath = 'breath';
  static const String _typeTaskStart = 'task_start';
  static const String _typeTaskPostpone = 'task_postpone';
  static const String _typeTaskConfirm = 'task_confirm';
  static const String _typeCoachCommand = 'coach_command';
  static const String _typeWeeklySurvey = 'weekly_survey';
  static const String _typeHealthTip = 'health_tip';
  static const String _typeMedicationReminder = 'medication_reminder';

  /// "Kabul Et" — starts the no-smoking window. Kept under its original id so
  /// notifications already scheduled on a user's device still resolve after
  /// an update.
  static const String _actionTaskDone = 'task_done';

  /// "Ertele" — opens the 5/10/15 choice below rather than snoozing by a
  /// fixed amount.
  static const String _actionTaskNotNow = 'task_not_now';

  static const String _actionTaskDecline = 'task_decline';
  static const String _actionTaskSos = 'task_sos';

  static const String _actionPostpone5 = 'task_postpone_5';
  static const String _actionPostpone10 = 'task_postpone_10';
  static const String _actionPostpone15 = 'task_postpone_15';

  /// The window elapsed and we're asking whether they got through it.
  ///
  /// Note the polarity: the question is "did you smoke?", so *yes* is the
  /// failure.
  static const String _actionConfirmSmokedYes = 'confirm_smoked_yes';
  static const String _actionConfirmSmokedNo = 'confirm_smoked_no';

  /// Body-tap on the task-start notification (not an action button) — a
  /// signal to HomePage to re-run its own mandatory-gate check, not an
  /// action HomePage or the background isolate should act on directly. Only
  /// ever dispatched when allowNavigation is true (see
  /// _processNotificationResponse): the gate needs a live HomePage/Navigator,
  /// which the cold background isolate never has.
  static const String mandatoryGateCheckActionId = 'mandatory_gate_check';

  /// "Tamam" / "Ertele" on a medication reminder. Only these two — no
  /// decline/SOS, unlike the task-trigger notification.
  static const String _actionMedicationTaken = 'medication_taken';
  static const String _actionMedicationPostpone = 'medication_postpone';
  static const Duration _medicationPostponeDelay = Duration(minutes: 15);

  static const String _postponeChannelId = 'task_postpone_channel_v1';
  static const String _taskConfirmChannelId = 'task_confirm_channel_v1';

  /// How many times one task may be postponed, and how many times SOS may be
  /// used on it.
  ///
  /// Both exist so an escape hatch doesn't become the whole flow. Without a
  /// cap, postponing indefinitely quietly turns every task into no task, and
  /// SOS — which suspends the task rather than failing it — becomes the
  /// costless way to never answer one. Two is enough for a genuinely bad
  /// moment and short of a habit.
  static const int maxPostponesPerTask = 2;
  static const int maxSosPerTask = 2;

  /// The answers a task offers, minus any the user has used up.
  ///
  /// Only SOS opens the app. The other three are recorded in the background
  /// isolate, because a task prompt that yanks the user out of whatever they
  /// were doing to answer it is its own small punishment for engaging. SOS is
  /// the exception on purpose: it leads into a breathing exercise, which is a
  /// screen by nature.
  ///
  /// Exhausted options are dropped rather than shown-and-refused: offering a
  /// button that answers with "no, not any more" is worse than not offering
  /// it, and on the third prompt the honest choices really are accept,
  /// decline, or say nothing.
  static List<AndroidNotificationAction> _taskTriggerActions(
    String code, {
    int postponeCount = 0,
    int sosCount = 0,
  }) {
    return <AndroidNotificationAction>[
      AndroidNotificationAction(
        _actionTaskDone,
        _text(code, 'taskActionDoneLabel'),
        showsUserInterface: false,
        cancelNotification: true,
      ),
      if (postponeCount < maxPostponesPerTask)
        AndroidNotificationAction(
          _actionTaskNotNow,
          _text(code, 'taskActionNotNowLabel'),
          showsUserInterface: false,
          cancelNotification: true,
        ),
      AndroidNotificationAction(
        _actionTaskDecline,
        _text(code, 'taskActionDeclineLabel'),
        showsUserInterface: false,
        cancelNotification: true,
      ),
      if (sosCount < maxSosPerTask)
        AndroidNotificationAction(
          _actionTaskSos,
          _text(code, 'taskActionSosLabel'),
          showsUserInterface: true,
          cancelNotification: true,
        ),
    ];
  }

  /// Reads how much of a task's postpone/SOS allowance is already spent.
  ///
  /// Returns zeroes for anything without a row — tasks issued before the
  /// assignments table existed, and the very first prompt of a new one.
  static Future<(int postponeCount, int sosCount)> _taskAllowanceFor(
    String taskTitle,
  ) async {
    try {
      final task = await StorageService().loadLatestTaskAssignmentByTitle(
        taskTitle,
      );
      if (task == null || task.isTerminal) {
        return (0, 0);
      }
      return (task.postponeCount, task.sosCount);
    } catch (_) {
      return (0, 0);
    }
  }

  /// Asks how long to postpone by, once "Ertele" has been tapped.
  ///
  /// A second notification rather than a dialog, because the whole point is
  /// that answering a task never opens the app. Notification actions can't
  /// nest, so the choice has to arrive as its own prompt.
  static Future<void> showPostponeChoiceNotification({
    required String taskTitle,
  }) async {
    final code = await LanguageService.loadSelectedLanguageCode();
    final id = _postponeChoiceIdFor(taskTitle);

    await _plugin.show(
      id,
      _text(code, 'postponeChoiceTitle'),
      _text(code, 'postponeChoiceBody'),
      NotificationDetails(
        android: AndroidNotificationDetails(
          _postponeChannelId,
          _text(code, 'channelNamePostponeChoice'),
          importance: Importance.high,
          priority: Priority.high,
          // Quiet: the user just answered a loud prompt, and a second alarm
          // for a follow-up question they asked for would read as nagging.
          playSound: false,
          enableVibration: false,
          visibility: NotificationVisibility.private,
          actions: <AndroidNotificationAction>[
            AndroidNotificationAction(
              _actionPostpone5,
              _text(code, 'postpone5Label'),
              showsUserInterface: false,
              cancelNotification: true,
            ),
            AndroidNotificationAction(
              _actionPostpone10,
              _text(code, 'postpone10Label'),
              showsUserInterface: false,
              cancelNotification: true,
            ),
            AndroidNotificationAction(
              _actionPostpone15,
              _text(code, 'postpone15Label'),
              showsUserInterface: false,
              cancelNotification: true,
            ),
          ],
        ),
        iOS: const DarwinNotificationDetails(
          categoryIdentifier: _categoryPostpone,
        ),
      ),
      payload: jsonEncode({'type': _typeTaskPostpone, 'taskTitle': taskTitle}),
    );
  }

  /// The end-of-window question, scheduled for when the barrier elapses.
  ///
  /// Worded as "did you smoke?", so **yes is the failure**. The older
  /// follow-up asked "did you complete the task?", where yes meant success —
  /// wiring these two the same way would invert every outcome the learning
  /// engine records, which is why the action ids are distinct rather than
  /// reused.
  static Future<void> scheduleTaskConfirmationPrompt({
    required String taskTitle,
    required Duration delay,
  }) async {
    final code = await LanguageService.loadSelectedLanguageCode();
    final scheduleMode = await _resolveAndroidScheduleMode();
    final fireAt = tz.TZDateTime.now(tz.local).add(delay);

    await _plugin.zonedSchedule(
      _confirmIdFor(taskTitle),
      _text(code, 'taskConfirmQuestionTitle'),
      _text(code, 'taskConfirmQuestion'),
      fireAt,
      NotificationDetails(
        android: AndroidNotificationDetails(
          _taskConfirmChannelId,
          _text(code, 'channelNameTaskConfirm'),
          importance: Importance.max,
          priority: Priority.high,
          playSound: true,
          enableVibration: true,
          vibrationPattern: _taskVibrationPattern,
          sound: _taskAlarmSound,
          audioAttributesUsage: AudioAttributesUsage.alarm,
          category: AndroidNotificationCategory.call,
          fullScreenIntent: true,
          visibility: NotificationVisibility.private,
          actions: <AndroidNotificationAction>[
            AndroidNotificationAction(
              _actionConfirmSmokedYes,
              _text(code, 'taskConfirmYesLabel'),
              showsUserInterface: false,
              cancelNotification: true,
            ),
            AndroidNotificationAction(
              _actionConfirmSmokedNo,
              _text(code, 'taskConfirmNoLabel'),
              showsUserInterface: false,
              cancelNotification: true,
            ),
          ],
        ),
        iOS: const DarwinNotificationDetails(
          categoryIdentifier: _categoryTaskConfirm,
        ),
      ),
      androidScheduleMode: scheduleMode,
      uiLocalNotificationDateInterpretation:
          UILocalNotificationDateInterpretation.absoluteTime,
      payload: jsonEncode({'type': _typeTaskConfirm, 'taskTitle': taskTitle}),
    );
  }

  /// How long an unanswered barrier-confirmation prompt is allowed to sit
  /// before the app stops trusting an answer given that late — see
  /// [scheduleBarrierResolutionReminder].
  static const Duration barrierResolutionDeadline = Duration(hours: 2);

  /// A second, lower-priority nudge for the same "did you smoke?" question
  /// [scheduleTaskConfirmationPrompt] already asked, fired
  /// [barrierResolutionDeadline] after it if the user never answered.
  ///
  /// Answering this one still resolves the task normally — same action ids,
  /// same payload type — so it's a reminder, not a second question. What it
  /// exists for is the case where the user never taps either notification at
  /// all: `syncBarrierResolutionOnStartup`'s app-open check uses this same
  /// deadline to close the task out as [TaskLifecycleState.barrierUnknown]
  /// once it's passed, so a barrier the app can no longer honestly evaluate
  /// doesn't sit open forever.
  static Future<void> scheduleBarrierResolutionReminder({
    required String taskTitle,
    required Duration delay,
  }) async {
    final code = await LanguageService.loadSelectedLanguageCode();
    final scheduleMode = await _resolveAndroidScheduleMode();
    final fireAt = tz.TZDateTime.now(
      tz.local,
    ).add(delay).add(barrierResolutionDeadline);

    await _plugin.zonedSchedule(
      _barrierResolutionReminderIdFor(taskTitle),
      _text(code, 'taskConfirmQuestionTitle'),
      _text(code, 'taskConfirmQuestion'),
      fireAt,
      NotificationDetails(
        android: AndroidNotificationDetails(
          _taskConfirmChannelId,
          _text(code, 'channelNameTaskConfirm'),
          importance: Importance.defaultImportance,
          priority: Priority.defaultPriority,
          playSound: false,
          enableVibration: false,
          visibility: NotificationVisibility.private,
          actions: <AndroidNotificationAction>[
            AndroidNotificationAction(
              _actionConfirmSmokedYes,
              _text(code, 'taskConfirmYesLabel'),
              showsUserInterface: false,
              cancelNotification: true,
            ),
            AndroidNotificationAction(
              _actionConfirmSmokedNo,
              _text(code, 'taskConfirmNoLabel'),
              showsUserInterface: false,
              cancelNotification: true,
            ),
          ],
        ),
        iOS: const DarwinNotificationDetails(
          categoryIdentifier: _categoryTaskConfirm,
        ),
      ),
      androidScheduleMode: scheduleMode,
      uiLocalNotificationDateInterpretation:
          UILocalNotificationDateInterpretation.absoluteTime,
      payload: jsonEncode({'type': _typeTaskConfirm, 'taskTitle': taskTitle}),
    );
  }

  /// Stable per-task ids so a re-issued prompt replaces its predecessor
  /// instead of stacking a second copy of the same question.
  static int _postponeChoiceIdFor(String taskTitle) =>
      (taskTitle.hashCode.abs() % 100000) + 810000;

  static int _confirmIdFor(String taskTitle) =>
      (taskTitle.hashCode.abs() % 100000) + 820000;

  static int _barrierResolutionReminderIdFor(String taskTitle) =>
      (taskTitle.hashCode.abs() % 100000) + 850000;

  /// Cancels the reminder [scheduleBarrierResolutionReminder] armed, once
  /// the task it was about has already been resolved some other way (the
  /// first confirmation prompt was answered, or the app-open check in
  /// `syncBarrierResolutionOnStartup` already closed it out) — otherwise it
  /// still fires on schedule and asks about a task nothing is waiting on
  /// an answer for any more.
  static Future<void> cancelBarrierResolutionReminder(String taskTitle) async {
    await _plugin.cancel(_barrierResolutionReminderIdFor(taskTitle));
  }

  static const String _categoryTaskStart = 'task_start_category';
  static const String _categoryPostpone = 'task_postpone_category';
  static const String _categoryTaskConfirm = 'task_confirm_category';
  // Bumped (v4->v5, v5->v6, v1->v2): Android freezes a channel's
  // sound/vibration settings the first time it's created and ignores code
  // changes afterward unless the channel ID itself changes — this forces
  // a fresh channel on devices that already had the app installed, so the
  // new alarm sound/vibration pattern actually takes effect.
  static const String _taskStartChannelId = 'task_start_channel_v5';
  static const String _taskEscalationChannelId = 'task_escalation_channel_v2';
  static const String _weeklySurveyChannelId = 'weekly_survey_channel_v1';
  static const String _sedentaryReminderChannelId =
      'sedentary_reminder_channel_v1';
  static const String _coachCommandChannelId = 'coach_command_channel_v1';
  static const int _sedentaryReminderNotificationId = 920001;
  static const int _sleepActivityAdvisoryNotificationId = 930001;
  static const int _snoringResultNotificationId = 930002;
  static const int _coughTestResultNotificationId = 930003;
  static const int _wheezeTestResultNotificationId = 930004;
  static const int _weeklySurveyNotificationId = 700001;
  static const String _healthTipChannelId = 'health_tip_channel_v2';
  static const int _healthTipBaseId = 430100;

  /// Upper bound for [scheduleHealthConditionAdviceNotifications] — mirrors
  /// the range NotificationKindsCard's picker offers. The actual per-day
  /// count (default 3) comes from [StorageService.loadDailyHealthTipCount].
  static const int _healthTipDailyCountMax = 5;

  /// The native health-tip-overlay alarm (AndroidWatchdogService.
  /// scheduleHealthTipTrigger) is shared by health tips and the weekly
  /// survey reminder — each caller needs its own slot range so cancelling/
  /// rescheduling one never clobbers another's alarm. Health tips own
  /// 0..[_healthTipDailyCountMax]-1 (see above).
  static const int _weeklySurveyOverlaySlot = 20;

  /// Id HealthTipTriggerReceiver caches the weekly survey reminder's fields
  /// under, so its "Postpone" button can reschedule without Dart.
  static const String _reminderIdWeeklySurvey = 'weekly_survey';
  static const String _routeBreathTest = 'breathTest';
  static const String _routeWeeklySurvey = 'weeklySurvey';
  static const String _medicationReminderChannelId =
      'medication_reminder_channel_v1';
  static const int _medicationReminderBaseId = 440100;
  static const int _medicationReminderMaxSlots = 30;

  /// Tip key prefixes per condition, numbered from 1 up to
  /// [_healthTipsPerCondition].
  ///
  /// Held as prefixes rather than an explicit list so the pool can grow
  /// without this map turning into hundreds of literals.
  static const Map<String, String> _healthTipPrefixByCondition = {
    'Hipertansiyon': 'healthTipHypertension',
    'Astim': 'healthTipAsthma',
    'Diyabet': 'healthTipDiabetes',
    'KOAH': 'healthTipCopd',
    'Kalp Hastaligi': 'healthTipHeartDisease',
  };

  /// How many tips exist per condition. Missing keys fall back to the
  /// English/Turkish text rather than showing a raw key, so a pool that has
  /// grown ahead of the translations degrades quietly.
  static const int _healthTipsPerCondition = 33;

  static const String _reservedTimesSettingKey =
      'reserved_notification_fire_times';
  // Retry cadence for a mandatory task alert nobody has answered yet: fire
  // again every 5 minutes, up to 3 attempts total, then give up (see
  // _scheduleUnansweredTaskUpdateReminder) -- matches the discipline
  // protocol's explicit retry contract, not an arbitrary escalation delay.
  static const Duration _unansweredReminderDelay = Duration(minutes: 5);
  static const int _maxTaskAttempts = 3;
  static final Int32List _insistentFlag = Int32List.fromList(<int>[4]);
  // A rhythmic buzz-pause-buzz pattern (not one flat 15s vibration) so it
  // actually reads as an alarm clock going off rather than a single long
  // rumble — combined with FLAG_INSISTENT above, Android replays this
  // (sound + vibration together) on a loop until the user responds.
  static final Int64List _taskVibrationPattern = Int64List.fromList(<int>[
    0,
    700,
    400,
    700,
    400,
    700,
    400,
    700,
  ]);
  // Device's own default alarm-clock sound (not the notification chime) —
  // reachable without bundling an audio asset. Combined with
  // AudioAttributesUsage.alarm (routes through the alarm volume stream,
  // not the notification stream) and the insistent flag above, this is
  // what actually makes these sound like a real alarm going off instead
  // of a normal notification ping.
  static const AndroidNotificationSound _taskAlarmSound =
      UriAndroidNotificationSound('content://settings/system/alarm_alert');

  static Stream<Map<String, String>> get taskActionStream =>
      _taskActionController.stream;

  static Future<void> initialize({
    GlobalKey<NavigatorState>? navigatorKey,
  }) async {
    _navigatorKey = navigatorKey;
    final code = await LanguageService.loadSelectedLanguageCode();
    tz.initializeTimeZones();
    final initSettings = InitializationSettings(
      android: const AndroidInitializationSettings('@mipmap/ic_launcher'),
      iOS: DarwinInitializationSettings(
        notificationCategories: <DarwinNotificationCategory>[
          DarwinNotificationCategory(
            _categoryTaskStart,
            actions: <DarwinNotificationAction>[
              DarwinNotificationAction.plain(
                _actionTaskDone,
                _text(code, 'taskActionDone'),
                options: <DarwinNotificationActionOption>{
                  DarwinNotificationActionOption.foreground,
                },
              ),
              DarwinNotificationAction.plain(
                _actionTaskNotNow,
                _text(code, 'taskActionNotNow'),
                options: <DarwinNotificationActionOption>{
                  DarwinNotificationActionOption.foreground,
                },
              ),
            ],
          ),
        ],
      ),
    );
    await _plugin.initialize(
      initSettings,
      onDidReceiveNotificationResponse: _handleNotificationResponse,
      onDidReceiveBackgroundNotificationResponse: notificationTapBackground,
    );

    await syncWatchdogViolationsFromNative();
    await syncOverlayStateFromNative();
    await _syncSleepActivityFromNative();
    await _syncSnoringResultFromNative();
    await _syncSmokedLogEventsFromNative();
    await _restoreSmokedLogButton(code);
    await AndroidWatchdogService.setTaskOverlayChannelInfo(
      channelName: _text(code, 'taskOverlayChannelName'),
      channelDescription: _text(code, 'taskOverlayChannelDescription'),
      foregroundBody: _text(code, 'taskOverlayForegroundBody'),
    );
    await SleepProbeService.setSnoringCaptureChannelInfo(
      title: _text(code, 'snoringCaptureNotificationTitle'),
      body: _text(code, 'snoringCaptureNotificationBody'),
      channelName: _text(code, 'snoringCaptureChannelName'),
    );
  }

  /// Puts the floating button back after a reboot or a process death.
  ///
  /// Android does not restart the overlay service on its own, so without this
  /// the button disappeared the first time the phone was restarted and never
  /// came back — the switch in settings still read "on", which made it look
  /// like the feature had simply stopped working.
  static Future<void> _restoreSmokedLogButton(String code) async {
    try {
      await SmokedLogButtonService().restoreIfEnabled(
        notificationTitle: _text(code, 'smokedLogButtonNotificationTitle'),
        notificationBody: _text(code, 'smokedLogButtonNotificationBody'),
        actionLabel: _text(code, 'smokedLogButtonAction'),
        menuLabels: {
          'menuTitle': _text(code, 'smokedLogMenuTitle'),
          'menuSosLabel': _text(code, 'smokedLogMenuSos'),
          'menuOpenLabel': _text(code, 'smokedLogMenuOpen'),
          'menuCancelLabel': _text(code, 'smokedLogMenuCancel'),
          'channelName': _text(code, 'channelNameSmokedLogQuickAction'),
          'channelDescription': _text(
            code,
            'channelDescriptionSmokedLogQuickAction',
          ),
        },
      );
    } catch (_) {
      // Best effort: the user can always toggle it again from settings.
    }
  }

  static Future<void> refreshLocalizedResources() async {
    await initialize(navigatorKey: _navigatorKey);
  }

  /// Writes any quick-log presses the floating button queued while the app
  /// wasn't running.
  ///
  /// The button lives in a native overlay with no Flutter engine behind it, so
  /// it can only leave timestamps in SharedPreferences; nothing reaches the
  /// database until this runs. Without it every press on a locked or closed
  /// phone — which is most of them — would be silently discarded, and both the
  /// weekly barrier review and the risky-hour ranking read from that table.
  ///
  /// Each drained row gets its own undo prompt: the lock-screen route (the
  /// only way to reach the button over the keyguard, see
  /// SmokedLogOverlayService.kt) is a single notification tap with no
  /// hold-to-confirm, so an accidental press has no guard until this runs.
  static Future<void> _syncSmokedLogEventsFromNative() async {
    try {
      final ids = await SmokedLogButtonService().drainPendingEvents();
      for (final id in ids) {
        await showSmokedLogUndoPrompt(eventId: id);
      }
    } catch (_) {
      // Best effort: a failed drain leaves the entries queued for next launch
      // rather than losing them.
    }
  }

  static const String _typeSmokedLogUndo = 'smoked_log_undo';
  static const String _actionSmokedLogUndo = 'smoked_log_undo';
  static const String _smokedLogUndoChannelId = 'smoked_log_undo_channel_v1';

  /// Offers to remove a cigarette the lock-screen quick-log button recorded.
  ///
  /// A plain notification, not the alarm-style task prompts — this confirms
  /// something that already happened rather than asking for anything, so it
  /// shouldn't compete for attention the way a mandatory task does.
  static Future<void> showSmokedLogUndoPrompt({required String eventId}) async {
    final code = await LanguageService.loadSelectedLanguageCode();
    final id = eventId.hashCode & 0x7fffffff;
    await _plugin.show(
      id,
      _text(code, 'smokedLogRecordedWithUndo'),
      _text(code, 'smokedLogUndoBody'),
      NotificationDetails(
        android: AndroidNotificationDetails(
          _smokedLogUndoChannelId,
          _text(code, 'channelNameSmokedLogUndo'),
          importance: Importance.defaultImportance,
          priority: Priority.defaultPriority,
          visibility: NotificationVisibility.private,
          actions: <AndroidNotificationAction>[
            AndroidNotificationAction(
              _actionSmokedLogUndo,
              _text(code, 'smokedLogUndoAction'),
              showsUserInterface: false,
              cancelNotification: true,
            ),
          ],
        ),
        iOS: const DarwinNotificationDetails(),
      ),
      payload: jsonEncode({'type': _typeSmokedLogUndo, 'eventId': eventId}),
    );
  }

  static Future<void> syncWatchdogViolationsFromNative() async {
    try {
      final rows = await AndroidWatchdogService.consumeViolations();
      if (rows.isEmpty) {
        return;
      }

      final storage = StorageService();
      for (final row in rows) {
        final type = row['type']?.toString() ?? 'no_response_10_min';
        final taskTitle = row['taskTitle']?.toString();
        final createdAtMillis = (row['createdAtMillis'] as num?)?.toInt();
        final createdAt = createdAtMillis == null
            ? DateTime.now()
            : DateTime.fromMillisecondsSinceEpoch(createdAtMillis);

        await storage.saveProtocolViolation(
          type: type,
          severity: 'high',
          source: 'queued_import',
          taskTitle: taskTitle,
          details:
              'All $_maxTaskAttempts retry attempts passed with no response to task notification.',
          createdAt: createdAt,
        );

        // Close the assignment row too. The watchdog runs natively while the
        // app is dead, so this queue is the only place a fully-unanswered
        // task is ever noticed; without this the row sat in `delivered`
        // forever, still counting against the postpone/SOS allowances and
        // still looking in-flight to anything that reads lifecycle state,
        // while the violation log and the adaptive engine had both already
        // written it off.
        //
        // A terminal transition writes the adaptive outcome itself, so when
        // it succeeds the explicit record below must be skipped — otherwise
        // one ignored task would be scored as two.
        final closedAssignment =
            taskTitle != null &&
            await _transitionTask(taskTitle, TaskLifecycleState.failedMissed);

        // The "did you smoke?" prompt for this task was scheduled the
        // moment it was accepted (scheduleTaskConfirmationPrompt), on its
        // own OS-level alarm — it has no idea the watchdog just closed the
        // task as missed, so left alone it still fires on schedule and asks
        // a question about a task that's already resolved. Same deterministic
        // id scheme as the scheduling call, so this reaches the exact alarm.
        // Cancelling both is a no-op on the (normal) case where the task was
        // never accepted in the first place, since neither was ever armed.
        if (taskTitle != null) {
          await _plugin.cancel(_confirmIdFor(taskTitle));
          await _plugin.cancel(_barrierResolutionReminderIdFor(taskTitle));
        }

        // Feeds the same "no response" event into the adaptive engine (see
        // AdaptiveTaskOutcome.missed) so difficultyLevel/streak react to it
        // exactly like any other failed task, not just the violation log.
        // Only meaningful for the canonical adaptive-plan task format --
        // other command types (coach commands, etc.) aren't tracked by the
        // adaptive engine at all, so there's nothing to record for those.
        final adaptiveMatch = closedAssignment || taskTitle == null
            ? null
            : RegExp(r'^ADAPTIVE_NO_SMOKE:(\d+)$').firstMatch(taskTitle.trim());
        if (adaptiveMatch != null) {
          final plannedMinutes =
              int.tryParse(adaptiveMatch.group(1) ?? '') ?? 30;
          await storage.recordAdaptiveTaskOutcome(
            taskTitle: taskTitle!,
            outcome: AdaptiveTaskOutcome.missed,
            plannedDurationMinutes: plannedMinutes,
            scheduledAt: createdAt.subtract(
              _unansweredReminderDelay * _maxTaskAttempts,
            ),
            respondedAt: createdAt,
          );
        }
      }
    } catch (_) {
      // Keep notification flow resilient even if native watchdog sync fails.
    }
  }

  static const Duration _sleepActivityNotificationCooldown = Duration(
    minutes: 30,
  );
  static const String _lastSleepActivityNotificationKey =
      'last_sleep_activity_notification_at';

  /// Drains "user was awake during their sleep window" events queued by the
  /// native sleep probe (see SleepProbeReceiver.kt / SleepActivityStore) and
  /// decides how to respond: a full mandatory task if today's plan quota
  /// isn't met yet (there's still real intervention work to do), or just a
  /// small advisory tip if it already is (no need to escalate). A cooldown
  /// collapses a run of closely-spaced events (the user staying awake
  /// across several 5-minute probe cycles) into a single notification
  /// rather than one per probe.
  static Future<void> _syncSleepActivityFromNative() async {
    try {
      final events = await SleepProbeService.consumeSleepActivityEvents();
      if (events.isEmpty) {
        return;
      }

      final storage = StorageService();
      final lastAtRaw = await storage.loadSetting(
        _lastSleepActivityNotificationKey,
      );
      final lastAt = lastAtRaw == null ? null : DateTime.tryParse(lastAtRaw);
      final now = DateTime.now();
      if (lastAt != null &&
          now.difference(lastAt) < _sleepActivityNotificationCooldown) {
        return;
      }

      await storage.saveSetting(
        _lastSleepActivityNotificationKey,
        now.toIso8601String(),
      );

      final quotaMet = await storage.isDailyTaskQuotaMet(now: now);
      if (quotaMet) {
        await _showSleepActivityAdvisory();
      } else {
        await showFirstTaskTriggerNotification(
          taskTitle: 'ADAPTIVE_NO_SMOKE:30',
          taskDescription: 'ADAPTIVE_NO_SMOKE:30',
        );
      }
    } catch (_) {
      // Keep notification flow resilient even if sleep-activity sync fails.
    }
  }

  static const String _lastSnoringResultNotificationDateKey =
      'last_snoring_result_notification_date';

  /// Tells the user what last night's (opt-in) Snoring Test actually found —
  /// until now the count only ever surfaced if they opened Settings and
  /// looked. Runs once per calendar day (keyed by date, not a rolling
  /// cooldown, since this is a once-a-night summary rather than an
  /// event-driven alert) and only when there's something to report: at
  /// least one probe fired, so the window wasn't skipped entirely.
  static Future<void> _syncSnoringResultFromNative() async {
    try {
      final storage = StorageService();
      final enabled =
          (await storage.loadSetting('snoring_detection_enabled')) == '1';
      if (!enabled) {
        return;
      }

      final today = DateTime.now();
      final todayKey =
          '${today.year}-${today.month.toString().padLeft(2, '0')}-${today.day.toString().padLeft(2, '0')}';
      final lastNotifiedKey = await storage.loadSetting(
        _lastSnoringResultNotificationDateKey,
      );
      if (lastNotifiedKey == todayKey) {
        return;
      }

      // 24h, not 12h — a 12h lookback anchored to "whenever the user opens
      // the app" misses last night entirely once the user opens the app
      // more than 12h after waking (e.g. slept 23:00-07:00, doesn't check
      // the app until 20:00 that evening). The once-a-day dedup key above
      // already guarantees this only ever shows once per calendar day, so
      // widening the window doesn't risk re-surfacing an older night.
      final since = today.subtract(const Duration(hours: 24));
      final probes = await storage.loadSnoringProbeEventsBetween(
        start: since,
        end: today,
      );
      if (probes.isEmpty) {
        // Nothing sampled yet tonight — don't claim a result before there
        // is one; this same check will run again on the next app open.
        return;
      }

      final snoreCount = probes.where((e) => e.snoreLikely).length;
      await storage.saveSetting(
        _lastSnoringResultNotificationDateKey,
        todayKey,
      );

      final code = await LanguageService.loadSelectedLanguageCode();
      var body = snoreCount > 0
          ? _text(
              code,
              'snoringResultNotificationBodyDetected',
            ).replaceAll('{count}', '$snoreCount')
          : _text(code, 'snoringResultNotificationBodyClear');

      final worstSeverity = _worstSnoringSeverity(probes);
      if (worstSeverity != null && worstSeverity != 'none') {
        body = '$body ${_text(code, _snoringSeverityBodyKey(worstSeverity))}';
      }

      await _plugin.show(
        _snoringResultNotificationId,
        _text(code, 'snoringResultNotificationTitle'),
        body,
        NotificationDetails(
          android: AndroidNotificationDetails(
            _healthTipChannelId,
            _text(code, 'channelNameHealthTip'),
            importance: Importance.defaultImportance,
            visibility: NotificationVisibility.private,
            priority: Priority.defaultPriority,
            playSound: true,
            enableVibration: true,
            audioAttributesUsage: AudioAttributesUsage.notificationRingtone,
            category: AndroidNotificationCategory.reminder,
          ),
          iOS: const DarwinNotificationDetails(presentSound: true),
        ),
        payload: jsonEncode({'type': _typeHealthTip}),
      );
    } catch (_) {
      // Keep notification flow resilient even if snoring-result sync fails.
    }
  }

  static const String _lastCoughResultNotificationDateKey =
      'last_cough_result_notification_date';

  /// Fired directly by CoughTestPage right after a test result is saved —
  /// unlike [_syncSnoringResultFromNative], there's no native-side queue to
  /// drain here: the cough test is user-initiated and synchronous, so the
  /// result is already known the moment this is called. Still capped to
  /// once per calendar day (same key convention as the snoring summary) so
  /// running the test more than once in a day doesn't re-notify for every
  /// attempt — the in-app result screen already shows every result
  /// immediately, this notification is a secondary nudge.
  static Future<void> showCoughTestResultAdvisory({
    required int coughCount,
    required String severityLevel,
  }) async {
    try {
      final storage = StorageService();
      final today = DateTime.now();
      final todayKey =
          '${today.year}-${today.month.toString().padLeft(2, '0')}-${today.day.toString().padLeft(2, '0')}';
      final lastNotifiedKey = await storage.loadSetting(
        _lastCoughResultNotificationDateKey,
      );
      if (lastNotifiedKey == todayKey) {
        return;
      }
      await storage.saveSetting(_lastCoughResultNotificationDateKey, todayKey);

      final code = await LanguageService.loadSelectedLanguageCode();
      final body = coughCount > 0
          ? _text(
              code,
              'coughTestResultCount',
            ).replaceAll('{count}', '$coughCount')
          : _text(code, 'coughTestResultCount').replaceAll('{count}', '0');

      await _plugin.show(
        _coughTestResultNotificationId,
        _text(code, 'coughTestNotificationTitle'),
        body,
        NotificationDetails(
          android: AndroidNotificationDetails(
            _healthTipChannelId,
            _text(code, 'channelNameHealthTip'),
            importance: Importance.defaultImportance,
            visibility: NotificationVisibility.private,
            priority: Priority.defaultPriority,
            playSound: true,
            enableVibration: true,
            audioAttributesUsage: AudioAttributesUsage.notificationRingtone,
            category: AndroidNotificationCategory.reminder,
          ),
          iOS: const DarwinNotificationDetails(presentSound: true),
        ),
        payload: jsonEncode({'type': _typeHealthTip}),
      );
    } catch (_) {
      // Keep notification flow resilient even if the cough-result
      // notification fails — the in-app result screen already showed it.
    }
  }

  static const String _lastWheezeResultNotificationDateKey =
      'last_wheeze_result_notification_date';

  /// Fired by CoughTestPage/BreathTestPage right after a test result with a
  /// detected acoustic wheeze is saved — same once-a-day dedup and
  /// resilient-to-failure shape as [showCoughTestResultAdvisory], its
  /// closest sibling. Only called when a wheeze was actually detected
  /// (callers check that before calling), so unlike the cough version there
  /// is no "nothing detected" body branch here.
  static Future<void> showWheezeTestResultAdvisory({
    required bool wheezeDetected,
    required String severityLevel,
  }) async {
    if (!wheezeDetected) {
      return;
    }
    try {
      final storage = StorageService();
      final today = DateTime.now();
      final todayKey =
          '${today.year}-${today.month.toString().padLeft(2, '0')}-${today.day.toString().padLeft(2, '0')}';
      final lastNotifiedKey = await storage.loadSetting(
        _lastWheezeResultNotificationDateKey,
      );
      if (lastNotifiedKey == todayKey) {
        return;
      }
      await storage.saveSetting(_lastWheezeResultNotificationDateKey, todayKey);

      final code = await LanguageService.loadSelectedLanguageCode();
      final body = _text(code, 'breathUnusualSoundAdvice');

      await _plugin.show(
        _wheezeTestResultNotificationId,
        _text(code, 'wheezeTestNotificationTitle'),
        body,
        NotificationDetails(
          android: AndroidNotificationDetails(
            _healthTipChannelId,
            _text(code, 'channelNameHealthTip'),
            importance: Importance.defaultImportance,
            visibility: NotificationVisibility.private,
            priority: Priority.defaultPriority,
            playSound: true,
            enableVibration: true,
            audioAttributesUsage: AudioAttributesUsage.notificationRingtone,
            category: AndroidNotificationCategory.reminder,
          ),
          iOS: const DarwinNotificationDetails(presentSound: true),
        ),
        payload: jsonEncode({'type': _typeHealthTip}),
      );
    } catch (_) {
      // Keep notification flow resilient even if the wheeze-result
      // notification fails — the in-app result screen already showed it.
    }
  }

  /// The worst severityLevel among last night's probes, or null when none
  /// carry a severity yet (probes recorded before this field existed) or no
  /// probe was snore-likely at all.
  static String? _worstSnoringSeverity(List<SnoringProbeEvent> probes) {
    const order = {'none': 0, 'mild': 1, 'moderate': 2, 'severe': 3};
    String? worst;
    var worstRank = -1;
    for (final probe in probes) {
      final level = probe.severityLevel;
      if (level == null) {
        continue;
      }
      final rank = order[level] ?? 0;
      if (rank > worstRank) {
        worstRank = rank;
        worst = level;
      }
    }
    return worst;
  }

  static String _snoringSeverityBodyKey(String severityLevel) {
    switch (severityLevel) {
      case 'severe':
        return 'snoringAdviceSevere';
      case 'moderate':
        return 'snoringAdviceModerate';
      default:
        return 'snoringAdviceMild';
    }
  }

  static Future<void> _showSleepActivityAdvisory() async {
    final code = await LanguageService.loadSelectedLanguageCode();
    await _plugin.show(
      _sleepActivityAdvisoryNotificationId,
      _text(code, 'sleepActivityAdvisoryTitle'),
      _text(code, 'sleepActivityAdvisoryBody'),
      NotificationDetails(
        android: AndroidNotificationDetails(
          _healthTipChannelId,
          _text(code, 'channelNameHealthTip'),
          importance: Importance.defaultImportance,
          visibility: NotificationVisibility.private,
          priority: Priority.defaultPriority,
          playSound: true,
          enableVibration: true,
          audioAttributesUsage: AudioAttributesUsage.notificationRingtone,
          category: AndroidNotificationCategory.reminder,
        ),
        iOS: const DarwinNotificationDetails(presentSound: true),
      ),
      payload: jsonEncode({'type': _typeHealthTip}),
    );
  }

  /// Call on app start and every resume: picks up a route a reminder
  /// overlay's "Open" button queued (see ReminderOverlayStore) and navigates
  /// there, then syncs any mandatory-task overlay outcomes the same way.
  static Future<void> syncOverlayStateFromNative() async {
    await _syncReminderOverlayRouteFromNative();
    await _syncTaskOverlayOutcomesFromNative();
    await _syncPendingShortcutActionFromNative();
  }

  /// Picks up a tap on one of the launcher icon's long-press shortcuts (see
  /// shortcuts.xml / MainActivity.ShortcutStore) — same queue-and-drain
  /// shape as the reminder-overlay route above, since the tap can arrive
  /// before any Flutter engine was ready to act on it directly. The
  /// self-challenge duration picker and craving support screen are the same
  /// ones QuickAction.selfChallenge/.craving open from the in-app menu (see
  /// quick_action_menu.dart) — a shortcut tap is just a different way to
  /// reach the same destinations. "smoked_now" logs immediately, same as
  /// picking it from the in-app menu.
  static Future<void> _syncPendingShortcutActionFromNative() async {
    try {
      final action = await AndroidWatchdogService.consumePendingShortcutAction();
      if (action == null || action.isEmpty) {
        return;
      }
      final context = _navigatorKey?.currentContext;
      if (context == null) {
        return;
      }
      switch (action) {
        case 'smoked_now':
          await StorageService().logSmokingNow();
        case 'craving':
          Navigator.of(
            context,
          ).push(MaterialPageRoute(builder: (_) => const CravingSosPage()));
        case 'self_challenge':
          final minutes = await showSelfChallengeDurationMenu(context);
          if (minutes == null) return;
          if (!context.mounted) return;
          Navigator.of(context).push(
            MaterialPageRoute(
              builder: (_) => SelfChallengePage(durationMinutes: minutes),
            ),
          );
      }
    } catch (_) {
      // Keep notification flow resilient even if shortcut sync fails.
    }
  }

  static Future<void> _syncReminderOverlayRouteFromNative() async {
    try {
      final route = await AndroidWatchdogService.consumeReminderOverlayRoute();
      if (route == null || route.isEmpty) {
        return;
      }
      final context = _navigatorKey?.currentContext;
      if (context == null) {
        return;
      }
      switch (route) {
        case _routeBreathTest:
          final hasOnboarded = await StorageService()
              .hasCompletedInitialSurvey();
          if (!hasOnboarded) {
            return;
          }
          Navigator.of(
            context,
          ).push(MaterialPageRoute(builder: (_) => const BreathTestPage()));
        case _routeWeeklySurvey:
          Navigator.of(
            context,
          ).push(MaterialPageRoute(builder: (_) => const WeeklySurveyPage()));
      }
    } catch (_) {
      // Keep notification flow resilient even if route sync fails.
    }
  }

  static Future<void> _syncTaskOverlayOutcomesFromNative() async {
    try {
      final rows = await AndroidWatchdogService.consumeTaskOverlayOutcomes();
      for (final row in rows) {
        final outcome = row['outcome']?.toString() ?? '';
        final taskTitle = row['taskTitle']?.toString() ?? '';
        if (taskTitle.isEmpty || outcome.isEmpty) {
          continue;
        }
        // The overlay now offers the same four answers the notification
        // does. Previously anything that wasn't "done" collapsed into
        // "postpone", so a decline recorded through the overlay was scored
        // as a deferral and never reached the learning engine as a failure.
        final actionId = switch (outcome) {
          'done' => _actionTaskDone,
          'postponed' => _actionTaskNotNow,
          'declined' => _actionTaskDecline,
          'sos' => _actionTaskSos,
          _ => _actionTaskNotNow,
        };
        _dispatchTaskAction({
          'type': _typeTaskStart,
          'taskTitle': taskTitle,
          'canonicalTitle': taskTitle,
          'actionId': actionId,
        });
      }
    } catch (_) {
      // Keep notification flow resilient even if overlay outcome sync fails.
    }
  }

  /// Status-only check (no system prompt) — for display in a settings/
  /// permissions screen. Use [ensureNotificationPermission] to actually
  /// request it.
  static Future<bool> areNotificationsEnabled() async {
    try {
      final androidPlugin = _plugin
          .resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin
          >();
      if (androidPlugin != null) {
        return await androidPlugin.areNotificationsEnabled() ?? true;
      }
    } catch (_) {
      // Best-effort on unsupported platforms.
    }
    return true;
  }

  static Future<bool> ensureNotificationPermission() async {
    bool enabled = true;
    bool fullScreenGranted = true;

    try {
      final androidPlugin = _plugin
          .resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin
          >();
      if (androidPlugin != null) {
        final granted = await androidPlugin.requestNotificationsPermission();
        final isEnabled = await androidPlugin.areNotificationsEnabled();
        enabled = (granted ?? true) && (isEnabled ?? true);
      }
    } catch (_) {
      // Keep best-effort behavior on unsupported devices.
    }

    try {
      final iosPlugin = _plugin
          .resolvePlatformSpecificImplementation<
            IOSFlutterLocalNotificationsPlugin
          >();
      if (iosPlugin != null) {
        final iosGranted =
            await iosPlugin.requestPermissions(
              alert: true,
              badge: true,
              sound: true,
            ) ??
            true;
        enabled = enabled && iosGranted;
      }
    } catch (_) {
      // Keep best-effort behavior on unsupported devices.
    }

    try {
      final dynamic androidPlugin = _plugin
          .resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin
          >();
      if (androidPlugin != null) {
        final dynamic requested = await androidPlugin
            .requestFullScreenIntentPermission();
        if (requested is bool) {
          fullScreenGranted = requested;
        }

        try {
          final dynamic canUse = await androidPlugin.canUseFullScreenIntent();
          if (canUse is bool) {
            fullScreenGranted = fullScreenGranted && canUse;
          }
        } catch (_) {
          // canUseFullScreenIntent may not exist depending on plugin/API level.
        }
      }
    } catch (_) {
      // Best-effort: fallback to current notification permission state.
    }

    return enabled && fullScreenGranted;
  }

  /// Requests the exact-alarm permission if it isn't already granted. On
  /// most devices this opens the system settings screen and returns once
  /// the user comes back; but if the permission was already granted (which
  /// happens automatically on API < 31, and can also already be true on API
  /// 31+ depending on how the OEM/user set things up), the plugin's native
  /// side sees `canScheduleExactAlarms() == true` and completes immediately
  /// without opening anything — there's nothing to grant. Returning that
  /// outcome lets the caller tell the user "already on" instead of the
  /// button silently appearing to do nothing.
  static Future<bool?> openExactAlarmSettingsOptional() async {
    try {
      final dynamic androidPlugin = _plugin
          .resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin
          >();
      return await androidPlugin?.requestExactAlarmsPermission() as bool?;
    } catch (_) {
      // Optional action: ignore on unsupported devices/APIs.
      return null;
    }
  }

  static Future<AndroidScheduleMode> _resolveAndroidScheduleMode() async {
    final androidPlugin = _plugin
        .resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin
        >();
    if (androidPlugin == null) {
      return AndroidScheduleMode.inexactAllowWhileIdle;
    }

    try {
      final canScheduleExact =
          await androidPlugin.canScheduleExactNotifications() ?? false;
      if (canScheduleExact) {
        return AndroidScheduleMode.exactAllowWhileIdle;
      }
    } catch (_) {
      // Fallback to inexact scheduling on unsupported devices/APIs.
    }

    return AndroidScheduleMode.inexactAllowWhileIdle;
  }

  static void _handleNotificationResponse(NotificationResponse response) {
    unawaited(_processNotificationResponse(response, allowNavigation: true));
  }

  static void handleBackgroundNotificationResponse(
    NotificationResponse response,
  ) {
    unawaited(_processNotificationResponse(response, allowNavigation: false));
  }

  static Future<void> _processNotificationResponse(
    NotificationResponse response, {
    required bool allowNavigation,
  }) async {
    final payload = _decodePayload(response.payload);
    if (payload == null) {
      return;
    }

    final reminderId = int.tryParse(payload['reminderId'] ?? '');
    if (reminderId != null) {
      unawaited(_plugin.cancel(reminderId));
    }

    final type = payload['type'];
    if (type == _typeBreath && allowNavigation) {
      // Never deep-link into BreathTestPage before the user has finished
      // the initial survey — a stale/queued daily reminder firing during
      // onboarding (splash/language-select/mid-survey) used to be able to
      // push BreathTestPage over whatever screen was active and, on
      // completion, route straight to HomePage — skipping SurveyPage
      // entirely and leaving the user stranded with no onboarding data.
      final hasOnboarded = await StorageService().hasCompletedInitialSurvey();
      if (!hasOnboarded) {
        return;
      }
      // Freshly fetched from the global navigator key (not a captured
      // widget BuildContext held across the gap above), so this is safe
      // despite the preceding await.
      final context = _navigatorKey?.currentContext;
      if (context != null) {
        Navigator.of(
          context,
        ).push(MaterialPageRoute(builder: (_) => const BreathTestPage()));
      }
      return;
    }

    if (type == _typeWeeklySurvey) {
      return;
    }

    if (type == _typeCoachCommand) {
      // A suggestion, not a task — dismissing it only cancels the
      // notification (already done above via reminderId). No task_assignments
      // row exists for it, so it must never reach _dispatchTaskAction.
      return;
    }

    if (type == _typeSmokedLogUndo) {
      if (response.actionId == _actionSmokedLogUndo) {
        final eventId = payload['eventId']?.trim() ?? '';
        if (eventId.isNotEmpty) {
          unawaited(StorageService().deleteSmokingEvent(eventId));
        }
      }
      return;
    }

    if (type == _typeMedicationReminder) {
      unawaited(
        _handleMedicationReminderAction(
          actionId: response.actionId ?? '',
          medicationId: payload['medicationId'] ?? '',
          medicationName: payload['medicationName'] ?? '',
        ),
      );
      return;
    }

    if (type == _typeTaskStart || type == _typeTaskConfirm) {
      final watchdogId = payload['watchdogId']?.trim() ?? '';
      if (watchdogId.isNotEmpty) {
        unawaited(AndroidWatchdogService.acknowledgeWatchdog(watchdogId));
      }

      final actionId = response.actionId;
      if (actionId == null || actionId.isEmpty) {
        // Body-tap: the notification body was tapped, not an action button.
        // Actions still go through _dispatchTaskAction below; this is the
        // separate case where nothing used to happen at all.
        if (type == _typeTaskConfirm && allowNavigation) {
          final taskTitle = payload['taskTitle'] ?? '';
          final canonicalTitle = payload['canonicalTitle'] ?? taskTitle;
          if (taskTitle.isNotEmpty) {
            unawaited(
              _openTaskSmokedConfirmPage(
                taskTitle: taskTitle,
                canonicalTitle: canonicalTitle,
              ),
            );
          }
        } else if (type == _typeTaskStart && allowNavigation) {
          // Ask HomePage to re-run its mandatory-gate check — which task (if
          // any) is due is HomePage's own decision
          // (_presentMandatoryTaskIfNeeded self-selects and is guarded by
          // _mandatoryTaskShown + a cooldown), so this never tries to push a
          // page directly and can't race a MandatoryTaskPage HomePage
          // already has open.
          _dispatchTaskAction({
            'type': type ?? '',
            'taskTitle': payload['taskTitle'] ?? '',
            'canonicalTitle':
                payload['canonicalTitle'] ?? payload['taskTitle'] ?? '',
            'actionId': mandatoryGateCheckActionId,
          });
        }
        return;
      }

      final event = {
        'type': type ?? '',
        'taskTitle': payload['taskTitle'] ?? '',
        // Falls back to taskTitle for notifications scheduled before this
        // field existed — they'll simply not resolve to a row, which is the
        // same as the behaviour they already had.
        'canonicalTitle':
            payload['canonicalTitle'] ?? payload['taskTitle'] ?? '',
        'actionId': actionId,
      };

      _dispatchTaskAction(event);
    }
  }

  /// Opens the "did you smoke?" page for a task-confirm notification's body
  /// tap. Mirrors the action-button path
  /// (TaskActionId.confirmSmokedYes/confirmSmokedNo →
  /// TaskAssignmentService.handleTaskAction) so both routes make the same
  /// decision through the same single point.
  static Future<void> _openTaskSmokedConfirmPage({
    required String taskTitle,
    required String canonicalTitle,
  }) async {
    final context = _navigatorKey?.currentContext;
    if (context == null) return;
    final smoked = await Navigator.of(context).push<bool>(
      MaterialPageRoute(
        builder: (_) => TaskSmokedConfirmPage(
          taskTitle: taskTitle,
          canonicalTitle: canonicalTitle,
        ),
      ),
    );
    if (smoked == null) return;
    final actionId = smoked
        ? TaskActionId.confirmSmokedYes
        : TaskActionId.confirmSmokedNo;
    await TaskAssignmentService(StorageService()).handleTaskAction(
      canonicalTitle: canonicalTitle,
      taskTitle: taskTitle,
      actionId: actionId,
    );
  }

  static void _dispatchTaskAction(Map<String, String> event) {
    if (_taskActionController.hasListener) {
      _taskActionController.add(event);
    } else {
      unawaited(_handleActionWithoutUi(event));
    }
  }

  /// Notification actions no longer open the app, so this runs in the
  /// background isolate `notificationTapBackground` spawns — a *cold* isolate
  /// that never ran [initialize] and therefore has none of its static setup.
  /// Everything below schedules follow-up notifications through
  /// `tz.TZDateTime`, which throws unless the timezone database was loaded in
  /// this isolate first. Cheap and idempotent, so it just runs every time.
  static void _ensureIsolateReady() {
    tz.initializeTimeZones();
  }

  /// Moves the task a notification belongs to into [state].
  ///
  /// Payloads carry only the canonical title, so the row has to be found by
  /// it. A no-op when nothing matches: tasks issued before this table existed
  /// have no row, and they should keep working through the older path rather
  /// than throwing here.
  /// Moves the assignment row for [taskTitle] to [state].
  ///
  /// Returns whether a row was actually moved. Callers that also write an
  /// adaptive outcome of their own need to know: a terminal transition
  /// records one itself, so doing both would score the same task twice.
  static Future<bool> _transitionTask(
    String taskTitle,
    String state, {
    int? postponeMinutes,
  }) async {
    try {
      final storage = StorageService();
      final task = await storage.loadLatestTaskAssignmentByTitle(taskTitle);
      if (task == null) {
        return false;
      }
      final updated = await storage.transitionTaskAssignment(
        id: task.id,
        state: state,
        postponeMinutes: postponeMinutes,
      );
      // Null, or already terminal before the call, means nothing moved.
      return updated != null && updated.state == state;
    } catch (_) {
      // Best effort — never let bookkeeping swallow the user's answer.
      return false;
    }
  }

  /// Opens the craving page for [canonicalTitle], so the breathing exercise
  /// knows which task to hand the user back to afterwards.
  ///
  /// Only reachable when the app is actually running — the SOS action is the
  /// one action declared `showsUserInterface: true`, so Android brings the
  /// app up first. If the navigator isn't ready yet the exercise is simply
  /// skipped; the task is already suspended either way, so nothing is lost
  /// beyond the screen itself.
  static void _openSosPage(String canonicalTitle) {
    final context = _navigatorKey?.currentContext;
    if (context == null) {
      return;
    }
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => CravingSosPage(taskCanonicalTitle: canonicalTitle),
      ),
    );
  }

  /// Opens the pre-sleep routine for [canonicalTitle], same reachability
  /// caveat as [_openSosPage] — only when the app is already running and a
  /// navigator exists. [name]/[packsPerDay] come from the latest survey
  /// record since, unlike the foreground path in HomePage, nothing here has
  /// them in memory already.
  static Future<void> _openSleepRoutinePage(String canonicalTitle) async {
    final storage = StorageService();
    final records = await storage.loadSurveyHistory();
    var name = '';
    var packsPerDay = '1 paketten az';
    for (final record in records.reversed) {
      if (record.packsPerDay.trim().isNotEmpty) {
        packsPerDay = record.packsPerDay;
        name = record.name;
        break;
      }
    }
    final context = _navigatorKey?.currentContext;
    if (context == null) {
      return;
    }
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => SleepRoutinePage(
          canonicalTitle: canonicalTitle,
          name: name,
          packsPerDay: packsPerDay,
        ),
      ),
    );
  }

  /// The set [TaskAssignmentService.handleTaskAction] now owns. Anything
  /// outside this set is a legacy follow-up action (see below) that never
  /// got a `task_assignments` row and still runs its own, older path.
  static const Set<String> _taskAssignmentActionIds = {
    _actionTaskDone,
    _actionTaskNotNow,
    _actionPostpone5,
    _actionPostpone10,
    _actionPostpone15,
    _actionTaskDecline,
    _actionTaskSos,
    _actionConfirmSmokedYes,
    _actionConfirmSmokedNo,
  };

  static Future<void> _handleActionWithoutUi(Map<String, String> event) async {
    final taskTitle = event['taskTitle']?.trim() ?? '';
    final actionId = event['actionId']?.trim() ?? '';
    if (taskTitle.isEmpty || actionId.isEmpty) {
      return;
    }
    // The exact ADAPTIVE_NO_SMOKE:<minutes> form. taskTitle is what the user
    // reads and varies by language, so it can't identify a stored task.
    final canonicalTitle = (event['canonicalTitle']?.trim().isNotEmpty ?? false)
        ? event['canonicalTitle']!.trim()
        : taskTitle;
    _ensureIsolateReady();

    if (_taskAssignmentActionIds.contains(actionId)) {
      final followUp = await TaskAssignmentService(StorageService())
          .handleTaskAction(
            canonicalTitle: canonicalTitle,
            taskTitle: taskTitle,
            actionId: actionId,
          );
      if (followUp == TaskActionFollowUp.openSosPage) {
        _openSosPage(canonicalTitle);
      } else if (followUp == TaskActionFollowUp.openSleepRoutinePage) {
        await _openSleepRoutinePage(canonicalTitle);
      }
    }
  }

  /// "Tamam" logs the dose as taken. "Ertele" logs the postponement and
  /// re-fires the same reminder [_medicationPostponeDelay] later as a
  /// one-off notification — the original daily-recurring notification (see
  /// `matchDateTimeComponents` in [scheduleMedicationReminders]) is left
  /// alone so tomorrow's dose still arrives on schedule.
  static Future<void> _handleMedicationReminderAction({
    required String actionId,
    required String medicationId,
    required String medicationName,
  }) async {
    if (medicationId.isEmpty) {
      return;
    }
    _ensureIsolateReady();
    final storage = StorageService();

    if (actionId == _actionMedicationTaken) {
      await storage.logMedicationDoseOutcome(
        medicationId: medicationId,
        outcome: 'taken',
      );
      return;
    }

    if (actionId == _actionMedicationPostpone) {
      await storage.logMedicationDoseOutcome(
        medicationId: medicationId,
        outcome: 'postponed',
      );
      await _scheduleMedicationPostponeReminder(
        medicationId: medicationId,
        medicationName: medicationName,
      );
    }
  }

  static Future<void> _scheduleMedicationPostponeReminder({
    required String medicationId,
    required String medicationName,
  }) async {
    final code = await LanguageService.loadSelectedLanguageCode();
    final fireAt = tz.TZDateTime.now(tz.local).add(_medicationPostponeDelay);
    final body = _text(
      code,
      'medicationReminderBody',
    ).replaceAll('{name}', medicationName);

    await _plugin.zonedSchedule(
      // Outside the recurring-slot id range so it can't collide with, or
      // get cancelled by, the daily reminders scheduleMedicationReminders
      // manages.
      _medicationReminderBaseId +
          _medicationReminderMaxSlots +
          (medicationId.hashCode.abs() % 10000),
      _text(code, 'medicationReminderTitle'),
      body,
      fireAt,
      NotificationDetails(
        android: AndroidNotificationDetails(
          _medicationReminderChannelId,
          _text(code, 'channelNameMedicationReminder'),
          importance: Importance.max,
          visibility: NotificationVisibility.private,
          priority: Priority.high,
          playSound: true,
          enableVibration: true,
          vibrationPattern: _taskVibrationPattern,
          fullScreenIntent: true,
          audioAttributesUsage: AudioAttributesUsage.notificationRingtone,
          category: AndroidNotificationCategory.reminder,
          actions: <AndroidNotificationAction>[
            AndroidNotificationAction(
              _actionMedicationTaken,
              _text(code, 'taskActionDoneLabel'),
              showsUserInterface: false,
              cancelNotification: true,
            ),
            AndroidNotificationAction(
              _actionMedicationPostpone,
              _text(code, 'taskActionNotNowLabel'),
              showsUserInterface: false,
              cancelNotification: true,
            ),
          ],
        ),
        iOS: const DarwinNotificationDetails(presentSound: true),
      ),
      androidScheduleMode: await _resolveAndroidScheduleMode(),
      uiLocalNotificationDateInterpretation:
          UILocalNotificationDateInterpretation.absoluteTime,
      payload: jsonEncode({
        'type': _typeMedicationReminder,
        'medicationId': medicationId,
        'medicationName': medicationName,
      }),
    );
  }

  static Map<String, String>? _decodePayload(String? raw) {
    if (raw == null || raw.trim().isEmpty) {
      return null;
    }
    try {
      final data = jsonDecode(raw) as Map<String, dynamic>;
      return data.map(
        (key, value) => MapEntry(key.toString(), value.toString()),
      );
    } catch (_) {
      return null;
    }
  }

  static int _deriveReminderId(int sourceId) {
    return (sourceId + 1000000000).remainder(2147483647);
  }

  /// Schedules attempt [attempt] (2 or 3) of the unanswered-task retry
  /// chain. Each attempt embeds the *next* attempt's reminderId in its own
  /// payload -- exactly the same "tapping this cancels reminderId" path
  /// _processNotificationResponse already uses for every other notification
  /// type, so responding to any attempt automatically cancels whichever
  /// attempt would have come after it. Recurses to schedule attempt 3 right
  /// after scheduling attempt 2; stops after attempt 3 (no attempt 4) --
  /// if that also goes unanswered, the native NoResponseWatchdogService's
  /// own timeout (armed for the full 3-attempt window, see
  /// scheduleFirstTaskTriggerNotification) is what ultimately marks the
  /// task missed.
  static Future<void> _scheduleUnansweredTaskUpdateReminder({
    required String taskTitle,
    required int reminderId,
    required tz.TZDateTime triggerAt,
    int attempt = 2,
  }) async {
    final code = await LanguageService.loadSelectedLanguageCode();
    final scheduleMode = await _resolveAndroidScheduleMode();
    final title = _text(code, 'taskEscalationTitle');
    final bodyPrefix = _text(code, 'taskEscalationBodyPrefix').replaceAll(
      '{minutes}',
      '${_unansweredReminderDelay.inMinutes}',
    );
    final body =
        '$bodyPrefix\n${AppTexts.localizeCanonicalTextForCode(code, taskTitle)}';

    final hasNextAttempt = attempt < _maxTaskAttempts;
    final nextReminderId = hasNextAttempt
        ? _deriveReminderId(reminderId)
        : null;
    final nextTriggerAt = hasNextAttempt
        ? triggerAt.add(_unansweredReminderDelay)
        : null;

    await _plugin.zonedSchedule(
      reminderId,
      title,
      body,
      triggerAt,
      NotificationDetails(
        android: AndroidNotificationDetails(
          _taskEscalationChannelId,
          _text(code, 'channelNameTaskUpdateReminder'),
          importance: Importance.max,
          visibility: NotificationVisibility.private,
          priority: Priority.high,
          playSound: true,
          enableVibration: true,
          vibrationPattern: _taskVibrationPattern,
          sound: _taskAlarmSound,
          additionalFlags: _insistentFlag,
          audioAttributesUsage: AudioAttributesUsage.alarm,
          category: AndroidNotificationCategory.reminder,
          actions: <AndroidNotificationAction>[
            AndroidNotificationAction(
              _actionTaskDone,
              _text(code, 'taskActionDoneLabel'),
              showsUserInterface: false,
              cancelNotification: true,
            ),
            AndroidNotificationAction(
              _actionTaskNotNow,
              _text(code, 'taskActionNotNowLabel'),
              showsUserInterface: false,
              cancelNotification: true,
            ),
          ],
        ),
        iOS: DarwinNotificationDetails(
          categoryIdentifier: _categoryTaskStart,
          presentSound: true,
        ),
      ),
      androidScheduleMode: scheduleMode,
      uiLocalNotificationDateInterpretation:
          UILocalNotificationDateInterpretation.absoluteTime,
      payload: jsonEncode({
        'type': _typeTaskStart,
        'taskTitle': taskTitle,
        if (nextReminderId != null) 'reminderId': '$nextReminderId',
      }),
    );

    if (hasNextAttempt && nextReminderId != null && nextTriggerAt != null) {
      await _scheduleUnansweredTaskUpdateReminder(
        taskTitle: taskTitle,
        reminderId: nextReminderId,
        triggerAt: nextTriggerAt,
        attempt: attempt + 1,
      );
    }
  }

  static Future<void> showFirstTaskTriggerNotification({
    required String taskTitle,
    required String taskDescription,
  }) async {
    final code = await LanguageService.loadSelectedLanguageCode();
    final interruptionContext = await _resolveInterruptionContext();
    final contextLabel =
        interruptionContext['contextLabel']?.toString() ?? 'normal';
    final confidence =
        (interruptionContext['confidence'] as num?)?.toDouble() ?? 0.0;
    await _persistNotificationContext(
      code: code,
      contextLabel: contextLabel,
      confidence: confidence,
    );
    final allowance = await _taskAllowanceFor(taskDescription);
    final adjustedDescription = contextLabel == 'eating'
        ? _text(code, 'postMealShieldCommand')
        : AppTexts.localizeCanonicalTextForCode(code, taskDescription);
    final id = DateTime.now().millisecondsSinceEpoch.remainder(2147483647);
    final reminderId = _deriveReminderId(id);
    final watchdogId = 'wdg_$id';
    // Spans the full retry chain (all _maxTaskAttempts, 5 min apart), not
    // just the first interval -- the watchdog should only fire its "truly
    // no response" violation once every attempt has had its turn.
    final dueAt = DateTime.now().add(
      _unansweredReminderDelay * _maxTaskAttempts,
    );
    await _plugin.show(
      id,
      _text(code, 'disciplineCommand'),
      '${_text(code, 'disciplineCommandBody')}\n$adjustedDescription',
      NotificationDetails(
        android: AndroidNotificationDetails(
          _taskStartChannelId,
          _text(code, 'channelNameFirstTaskTrigger'),
          importance: Importance.max,
          visibility: NotificationVisibility.private,
          priority: Priority.high,
          playSound: true,
          enableVibration: true,
          vibrationPattern: _taskVibrationPattern,
          sound: _taskAlarmSound,
          additionalFlags: _insistentFlag,
          autoCancel: false,
          ongoing: true,
          onlyAlertOnce: false,
          audioAttributesUsage: AudioAttributesUsage.alarm,
          category: AndroidNotificationCategory.call,
          fullScreenIntent: true,
          actions: _taskTriggerActions(
            code,
            postponeCount: allowance.$1,
            sosCount: allowance.$2,
          ),
        ),
        iOS: const DarwinNotificationDetails(
          categoryIdentifier: _categoryTaskStart,
        ),
      ),
      payload: jsonEncode({
        'type': _typeTaskStart,
        'taskTitle': taskTitle,
        // The exact ADAPTIVE_NO_SMOKE:<minutes> form, carried separately.
        // `taskTitle` here is the on-screen heading and the other trigger
        // notification puts localised text in the same field, so neither can
        // be matched back to a task_assignments row — a lookup on them finds
        // nothing and silently does nothing.
        'canonicalTitle': taskDescription,
        'reminderId': '$reminderId',
        'watchdogId': watchdogId,
      }),
    );

    await AndroidWatchdogService.startWatchdog(
      taskTitle: taskTitle,
      watchdogId: watchdogId,
      dueAt: dueAt,
      foregroundBody: _text(code, 'watchdogForegroundBody'),
      violationTitle: _text(code, 'watchdogViolationTitle'),
      violationBody: _text(code, 'watchdogViolationBody'),
      foregroundChannelName: _text(code, 'watchdogForegroundChannel'),
      violationChannelName: _text(code, 'watchdogViolationChannel'),
    );

    final reminderAt = tz.TZDateTime.now(
      tz.local,
    ).add(_unansweredReminderDelay);
    await _scheduleUnansweredTaskUpdateReminder(
      taskTitle: taskTitle,
      reminderId: reminderId,
      triggerAt: reminderAt,
    );
  }

  static Future<void> scheduleFirstTaskTriggerNotification({
    required String taskDescription,
    Duration delay = const Duration(minutes: 10),

    /// The `task_assignments` row this notification is for, when one
    /// exists. Threading it through as the watchdogId (rather than the
    /// freshly-generated `wdg_<id>` below) is what lets a native delivery
    /// event — an expiry from the pending-delivery queue limit, a watchdog
    /// violation — be matched straight back to its row by id instead of by
    /// canonicalTitle, which stops working the moment two tasks share a
    /// title. Left null for call sites with no row yet (older payload
    /// shapes, code paths not yet wired to task_assignments).
    String? taskAssignmentId,
  }) async {
    final code = await LanguageService.loadSelectedLanguageCode();
    final scheduleMode = await _resolveAndroidScheduleMode();
    final interruptionContext = await _resolveInterruptionContext();
    final extraDelay =
        (interruptionContext['recommendedDeferralMinutes'] as int?) ?? 0;
    final contextLabel =
        interruptionContext['contextLabel']?.toString() ?? 'normal';
    final confidence =
        (interruptionContext['confidence'] as num?)?.toDouble() ?? 0.0;
    await _persistNotificationContext(
      code: code,
      contextLabel: contextLabel,
      confidence: confidence,
    );
    final now = tz.TZDateTime.now(tz.local);
    final fireAt = now.add(delay).add(Duration(minutes: extraDelay));
    final allowance = await _taskAllowanceFor(taskDescription);
    final adjustedDescription = contextLabel == 'eating'
        ? _text(code, 'postMealShieldCommand')
        : AppTexts.localizeCanonicalTextForCode(code, taskDescription);
    final id = DateTime.now().millisecondsSinceEpoch.remainder(2147483647);
    final reminderId = _deriveReminderId(id);
    final watchdogId = taskAssignmentId ?? 'wdg_$id';
    await _plugin.zonedSchedule(
      id,
      _text(code, 'disciplineCommand'),
      '${_text(code, 'disciplineCommandBody')}\n$adjustedDescription',
      fireAt,
      NotificationDetails(
        android: AndroidNotificationDetails(
          _taskStartChannelId,
          _text(code, 'channelNameFirstTaskTrigger'),
          importance: Importance.max,
          visibility: NotificationVisibility.private,
          priority: Priority.high,
          playSound: true,
          enableVibration: true,
          vibrationPattern: _taskVibrationPattern,
          sound: _taskAlarmSound,
          additionalFlags: _insistentFlag,
          autoCancel: false,
          ongoing: true,
          onlyAlertOnce: false,
          audioAttributesUsage: AudioAttributesUsage.alarm,
          category: AndroidNotificationCategory.call,
          fullScreenIntent: true,
          actions: _taskTriggerActions(
            code,
            postponeCount: allowance.$1,
            sosCount: allowance.$2,
          ),
        ),
        iOS: const DarwinNotificationDetails(
          categoryIdentifier: _categoryTaskStart,
        ),
      ),
      androidScheduleMode: scheduleMode,
      uiLocalNotificationDateInterpretation:
          UILocalNotificationDateInterpretation.absoluteTime,
      payload: jsonEncode({
        'type': _typeTaskStart,
        'taskTitle': adjustedDescription,
        // See showFirstTaskTriggerNotification: adjustedDescription is the
        // localised, user-facing wording, so the canonical form has to travel
        // alongside it for the task row to be findable.
        'canonicalTitle': taskDescription,
        'reminderId': '$reminderId',
        'watchdogId': watchdogId,
      }),
    );

    // Armed for [fireAt], not for now: the overlay has to be raised at the
    // moment the task is actually due (a scheduled notification can't start
    // it, and with the app closed no Dart is running then), and the watchdog
    // has to start counting from when the user was really asked. Starting it
    // here instead would have it poll in the foreground for however many
    // hours away the task is — and, because WatchdogStore keeps a single
    // active entry, two tasks scheduled in the same session would overwrite
    // each other's watchdog.
    await AndroidWatchdogService.scheduleTaskTrigger(
      title: _text(code, 'disciplineCommand'),
      body: adjustedDescription,
      doneLabel: _text(code, 'taskActionDoneLabel'),
      // Blank when the allowance is spent, so the overlay shows exactly the
      // same answers the notification does.
      postponeLabel: allowance.$1 < maxPostponesPerTask
          ? _text(code, 'taskActionNotNowLabel')
          : '',
      declineLabel: _text(code, 'taskActionDeclineLabel'),
      sosLabel: allowance.$2 < maxSosPerTask
          ? _text(code, 'taskActionSosLabel')
          : '',
      watchdogId: watchdogId,
      taskTitle: adjustedDescription,
      triggerAt: fireAt,
      watchdogWindow: _unansweredReminderDelay * _maxTaskAttempts,
      watchdogForegroundBody: _text(code, 'watchdogForegroundBody'),
      watchdogViolationTitle: _text(code, 'watchdogViolationTitle'),
      watchdogViolationBody: _text(code, 'watchdogViolationBody'),
      watchdogForegroundChannelName: _text(code, 'watchdogForegroundChannel'),
      watchdogViolationChannelName: _text(code, 'watchdogViolationChannel'),
    );

    await _scheduleUnansweredTaskUpdateReminder(
      taskTitle: adjustedDescription,
      reminderId: reminderId,
      triggerAt: fireAt.add(_unansweredReminderDelay),
    );
  }

  /// The instant at which the clock on the user's phone reads [hour]:[minute].
  ///
  /// `tz.local` is UTC in this app — `setLocalLocation` is never called,
  /// because nothing here can resolve the device's IANA zone name. That made
  /// `tz.TZDateTime(tz.local, y, m, d, hour, minute)` mean "that wall clock in
  /// UTC": someone in UTC+3 asking to be reminded at 21:00 was scheduled for
  /// 00:00 the following day. Building from a plain local [DateTime] instead
  /// pins the correct absolute instant, which is what `absoluteTime`
  /// scheduling actually consumes — no timezone-name lookup needed.
  static tz.TZDateTime _atDeviceTimeOfDay(
    int hour,
    int minute, {
    int addDays = 0,
  }) {
    final today = DateTime.now();
    return tz.TZDateTime.from(
      DateTime(today.year, today.month, today.day + addDays, hour, minute),
      tz.local,
    );
  }

  /// A few short, condition-specific tips spread across the user's waking
  /// hours — cycles through whichever conditions the user picked in the
  /// initial survey (see SurveyPage._selectedHealthConditions), rotating
  /// which condition's tip lands in each daily slot rather than always
  /// leading with the same one. No-ops (after clearing any previously
  /// scheduled slots) when the user selected no conditions.
  static Future<void> scheduleHealthConditionAdviceNotifications({
    required List<String> healthConditions,
    required String wakeTime,
    required String sleepTime,
  }) async {
    for (var i = 0; i < _healthTipDailyCountMax; i++) {
      await _plugin.cancel(_healthTipBaseId + i);
      await AndroidWatchdogService.cancelHealthTipTrigger(i);
    }
    if (healthConditions.isEmpty) {
      return;
    }

    // The caller passes the static survey/settings window, but the user's
    // actual sleep schedule can drift from that over time. Sleep
    // Intelligence (when enabled) tracks the real window from overnight
    // probes — resolve against that so tips land in waking hours instead of
    // the stale configured ones.
    final effectiveWindow = await StorageService().resolveEffectiveSleepWindow(
      fallbackSleepTime: sleepTime,
      fallbackWakeTime: wakeTime,
    );
    final resolvedWakeTime = effectiveWindow.wakeTime ?? wakeTime;
    final resolvedSleepTime = effectiveWindow.sleepTime ?? sleepTime;

    // Condition advice used to skip anyone taking medication, on the theory
    // that their tip already rode along with a reminder they got anyway —
    // but medication reminders no longer carry a tip (they say one thing:
    // take this medication now), so every user with a tracked condition
    // gets this regardless of whether they also take medication.

    final dailyCount = (await StorageService().loadDailyHealthTipCount()).clamp(
      1,
      _healthTipDailyCountMax,
    );

    final scheduleMode = await _resolveAndroidScheduleMode();
    final code = await LanguageService.loadSelectedLanguageCode();
    final now = tz.TZDateTime.now(tz.local);

    final wakeParts = resolvedWakeTime.split(':');
    final wakeHour = int.tryParse(wakeParts[0]) ?? 7;
    final wakeMinute =
        int.tryParse(wakeParts.length > 1 ? wakeParts[1] : '0') ?? 0;

    final sleepParts = resolvedSleepTime.split(':');
    final sleepHour = int.tryParse(sleepParts[0]) ?? 21;
    final sleepMinute =
        int.tryParse(sleepParts.length > 1 ? sleepParts[1] : '0') ?? 0;

    var wakeAt = _atDeviceTimeOfDay(wakeHour, wakeMinute);
    var sleepAt = _atDeviceTimeOfDay(sleepHour, sleepMinute);
    if (!sleepAt.isAfter(wakeAt)) {
      sleepAt = sleepAt.add(const Duration(days: 1));
    }

    final windowMinutes = sleepAt.difference(wakeAt).inMinutes;
    final intervalMinutes = windowMinutes ~/ (dailyCount + 1);

    var conditionCursor = 0;
    var variantCursor = 0;
    for (var i = 0; i < dailyCount; i++) {
      var fireAt = wakeAt.add(Duration(minutes: intervalMinutes * (i + 1)));
      if (!fireAt.isAfter(now)) {
        fireAt = fireAt.add(const Duration(days: 1));
      }
      fireAt = await _reserveNonConflictingTime(fireAt);
      if (!await _budgetAllows(
        NotificationKind.healthTip,
        at: fireAt,
        lowestPendingOfferedPriority: const NotificationBudget().priorityOf(
          NotificationKind.healthTip,
        ),
      )) {
        continue;
      }

      final condition =
          healthConditions[conditionCursor % healthConditions.length];
      final prefix = _healthTipPrefixByCondition[condition];
      conditionCursor++;
      if (prefix == null) {
        continue;
      }
      final tipKey = '$prefix${(variantCursor % _healthTipsPerCondition) + 1}';
      variantCursor++;

      await _plugin.zonedSchedule(
        _healthTipBaseId + i,
        _text(code, 'healthTipTitle'),
        '${_text(code, tipKey)}\n${_text(code, 'medicationAdviceDisclaimer')}',
        fireAt,
        NotificationDetails(
          android: AndroidNotificationDetails(
            _healthTipChannelId,
            _text(code, 'channelNameHealthTip'),
            importance: Importance.max,
            visibility: NotificationVisibility.private,
            priority: Priority.high,
            playSound: true,
            enableVibration: true,
            vibrationPattern: _taskVibrationPattern,
            fullScreenIntent: true,
            audioAttributesUsage: AudioAttributesUsage.notificationRingtone,
            category: AndroidNotificationCategory.reminder,
          ),
          iOS: const DarwinNotificationDetails(presentSound: true),
        ),
        androidScheduleMode: scheduleMode,
        matchDateTimeComponents: DateTimeComponents.time,
        uiLocalNotificationDateInterpretation:
            UILocalNotificationDateInterpretation.absoluteTime,
        payload: jsonEncode({'type': _typeHealthTip}),
      );

      // Also arms a native alarm that shows the same tip as an info overlay
      // over whatever app is in the foreground at fireAt — the notification
      // alone only surfaces if the user is on the lock screen or taps it.
      await AndroidWatchdogService.scheduleHealthTipTrigger(
        slot: i,
        title: _text(code, 'healthTipTitle'),
        body:
            '${_text(code, tipKey)}\n${_text(code, 'medicationAdviceDisclaimer')}',
        dismissLabel: _text(code, 'taskActionDoneLabel'),
        triggerAt: fireAt,
      );
    }
  }

  static Future<void> scheduleMedicationReminders(
    List<Medication> medications,
  ) async {
    for (var i = 0; i < _medicationReminderMaxSlots; i++) {
      await _plugin.cancel(_medicationReminderBaseId + i);
    }
    if (medications.isEmpty) {
      return;
    }

    final scheduleMode = await _resolveAndroidScheduleMode();
    final code = await LanguageService.loadSelectedLanguageCode();
    final now = tz.TZDateTime.now(tz.local);

    var slot = 0;
    for (final medication in medications) {
      for (final time in medication.times) {
        if (slot >= _medicationReminderMaxSlots) {
          return;
        }
        final parts = time.split(':');
        final hour = int.tryParse(parts[0]) ?? 8;
        final minute = int.tryParse(parts.length > 1 ? parts[1] : '0') ?? 0;
        var fireAt = _atDeviceTimeOfDay(hour, minute);
        if (!fireAt.isAfter(now)) {
          fireAt = fireAt.add(const Duration(days: 1));
        }
        fireAt = await _reserveNonConflictingTime(fireAt);

        // A medication reminder says one thing: take this medication now.
        // Condition-specific advice used to ride along here, but that made
        // the reminder read as two different messages at once — the tip
        // now arrives on its own via scheduleHealthConditionAdviceNotifications,
        // which every user with a tracked condition receives regardless of
        // whether they also take medication.
        final body = _text(
          code,
          'medicationReminderBody',
        ).replaceAll('{name}', medication.name);

        await _plugin.zonedSchedule(
          _medicationReminderBaseId + slot,
          _text(code, 'medicationReminderTitle'),
          body,
          fireAt,
          NotificationDetails(
            android: AndroidNotificationDetails(
              _medicationReminderChannelId,
              _text(code, 'channelNameMedicationReminder'),
              importance: Importance.max,
              visibility: NotificationVisibility.private,
              priority: Priority.high,
              playSound: true,
              enableVibration: true,
              vibrationPattern: _taskVibrationPattern,
              // Taking a dose on time matters enough to route through the
              // alarm stream (not just the notification chime) and repeat
              // sound+vibration until answered — same treatment a mandatory
              // task gets, see _taskAlarmSound/_insistentFlag.
              sound: _taskAlarmSound,
              additionalFlags: _insistentFlag,
              fullScreenIntent: true,
              audioAttributesUsage: AudioAttributesUsage.alarm,
              category: AndroidNotificationCategory.alarm,
              actions: <AndroidNotificationAction>[
                AndroidNotificationAction(
                  _actionMedicationTaken,
                  _text(code, 'taskActionDoneLabel'),
                  showsUserInterface: false,
                  cancelNotification: true,
                ),
                AndroidNotificationAction(
                  _actionMedicationPostpone,
                  _text(code, 'taskActionNotNowLabel'),
                  showsUserInterface: false,
                  cancelNotification: true,
                ),
              ],
            ),
            iOS: const DarwinNotificationDetails(presentSound: true),
          ),
          androidScheduleMode: scheduleMode,
          matchDateTimeComponents: DateTimeComponents.time,
          uiLocalNotificationDateInterpretation:
              UILocalNotificationDateInterpretation.absoluteTime,
          payload: jsonEncode({
            'type': _typeMedicationReminder,
            'medicationId': medication.id,
            'medicationName': medication.name,
          }),
        );
        slot++;
      }
    }
  }

  static Future<void> scheduleWeeklySurveyDueReminder({
    required DateTime dueAt,
    bool forceImmediateIfOverdue = true,
  }) async {
    final scheduleMode = await _resolveAndroidScheduleMode();
    final code = await LanguageService.loadSelectedLanguageCode();
    final now = tz.TZDateTime.now(tz.local);
    var fireAt = tz.TZDateTime.from(dueAt, tz.local);
    if (!fireAt.isAfter(now)) {
      if (!forceImmediateIfOverdue) {
        return;
      }
      fireAt = now.add(const Duration(minutes: 1));
    }
    // Not run through the daily budget: this fires at most once a week, so
    // the risk of budget exhaustion pushing it into next week outweighs the
    // benefit of coordinating with same-day notifications. The shared
    // spacing gap still applies.
    fireAt = await _reserveNonConflictingTime(fireAt);

    await _plugin.cancel(_weeklySurveyNotificationId);
    await _plugin.zonedSchedule(
      _weeklySurveyNotificationId,
      _text(code, 'weeklySurveyReminderTitle'),
      _text(code, 'weeklySurveyReminderBody'),
      fireAt,
      NotificationDetails(
        android: AndroidNotificationDetails(
          _weeklySurveyChannelId,
          _text(code, 'channelNameWeeklySurveyReminder'),
          importance: Importance.max,
          visibility: NotificationVisibility.private,
          priority: Priority.high,
          playSound: true,
          enableVibration: true,
          vibrationPattern: _taskVibrationPattern,
          audioAttributesUsage: AudioAttributesUsage.notificationRingtone,
          category: AndroidNotificationCategory.reminder,
        ),
        iOS: const DarwinNotificationDetails(presentSound: true),
      ),
      androidScheduleMode: scheduleMode,
      uiLocalNotificationDateInterpretation:
          UILocalNotificationDateInterpretation.absoluteTime,
      payload: jsonEncode({'type': _typeWeeklySurvey}),
    );

    // Also arms a native alarm that shows the same reminder as an
    // Open/Postpone overlay over whatever app is in the foreground.
    await AndroidWatchdogService.scheduleReminderOverlayTrigger(
      slot: _weeklySurveyOverlaySlot,
      reminderId: _reminderIdWeeklySurvey,
      title: _text(code, 'weeklySurveyReminderTitle'),
      body: _text(code, 'weeklySurveyReminderBody'),
      route: _routeWeeklySurvey,
      openLabel: _text(code, 'taskActionDoneLabel'),
      postponeLabel: _text(code, 'taskActionNotNowLabel'),
      triggerAt: fireAt,
    );
  }

  static Future<void> cancelWeeklySurveyReminder() async {
    await _plugin.cancel(_weeklySurveyNotificationId);
    await AndroidWatchdogService.cancelHealthTipTrigger(
      _weeklySurveyOverlaySlot,
    );
  }

  static Future<void> showTaskTimerStartedNotification({
    required String taskTitle,
    required Duration duration,
  }) async {
    final code = await LanguageService.loadSelectedLanguageCode();
    final id = DateTime.now().millisecondsSinceEpoch.remainder(2147483647);
    await _plugin.show(
      id,
      _text(code, 'taskTimerStartedTitle'),
      '${_text(code, 'taskTimerStartedBody')}\n${AppTexts.localizeCanonicalTextForCode(code, taskTitle)}\n${_text(code, 'taskTimerDuration')}: ${duration.inMinutes} ${_text(code, 'minutesShort')}.',
      NotificationDetails(
        android: AndroidNotificationDetails(
          _taskStartChannelId,
          _text(code, 'channelNameTaskTimerStart'),
          importance: Importance.max,
          visibility: NotificationVisibility.private,
          priority: Priority.high,
          playSound: true,
          enableVibration: true,
          vibrationPattern: _taskVibrationPattern,
          // fullScreenIntent (not the alarm sound/insistent-loop combo the
          // actual task-trigger alert uses) is enough to make this land as
          // a large, hard-to-miss banner — this fires right after the user
          // already said yes to a task, so it should be clearly visible,
          // not urgently repeating.
          fullScreenIntent: true,
          audioAttributesUsage: AudioAttributesUsage.notificationRingtone,
          category: AndroidNotificationCategory.reminder,
        ),
        iOS: const DarwinNotificationDetails(presentSound: true),
      ),
    );
  }

  static Future<void> showDurationBarrierStartedNotification({
    required String taskTitle,
    required Duration duration,
  }) async {
    final code = await LanguageService.loadSelectedLanguageCode();
    final id = DateTime.now().millisecondsSinceEpoch.remainder(2147483647);
    final durationText = AppTexts.formatAdaptiveDurationPhrase(
      code,
      duration.inMinutes,
    );
    final instruction = _text(
      code,
      'barrierStartedInstruction',
    ).replaceAll('{duration}', durationText);
    await _plugin.show(
      id,
      _text(code, 'barrierStartedTitle'),
      '$instruction\n${AppTexts.localizeCanonicalTextForCode(code, taskTitle)}\n${_text(code, 'barrierStartedDuration')}: $durationText.',
      NotificationDetails(
        android: AndroidNotificationDetails(
          _taskStartChannelId,
          _text(code, 'channelNameDurationBarrierCall'),
          importance: Importance.max,
          visibility: NotificationVisibility.private,
          priority: Priority.high,
          playSound: true,
          enableVibration: true,
          vibrationPattern: _taskVibrationPattern,
          audioAttributesUsage: AudioAttributesUsage.notificationRingtone,
          category: AndroidNotificationCategory.call,
          fullScreenIntent: true,
        ),
        iOS: const DarwinNotificationDetails(presentSound: true),
      ),
    );
  }

  /// Phase 11: a gentle "get up and move" nudge — deliberately styled like
  /// the breath-test reminder (normal ringtone, no insistent flag, no
  /// full-screen takeover) rather than the alarm-style task notifications,
  /// since this is a wellness suggestion the user can freely ignore, not
  /// something the discipline protocol needs an answer to.
  static Future<void> showSedentaryReminderNotification() async {
    // Lowest priority of anything offered — if the day's budget is spoken
    // for, this is the first thing to give way, and never at the cost of a
    // measurement that cannot be taken again later.
    if (!await _budgetAllows(
      NotificationKind.sedentary,
      lowestPendingOfferedPriority: const NotificationBudget().priorityOf(
        NotificationKind.sedentary,
      ),
    )) {
      return;
    }
    final code = await LanguageService.loadSelectedLanguageCode();
    await _plugin.show(
      _sedentaryReminderNotificationId,
      _text(code, 'sedentaryReminderTitle'),
      _text(code, 'sedentaryReminderBody'),
      NotificationDetails(
        android: AndroidNotificationDetails(
          _sedentaryReminderChannelId,
          _text(code, 'channelNameMovementReminder'),
          importance: Importance.high,
          visibility: NotificationVisibility.private,
          priority: Priority.high,
          playSound: true,
          // Default vibration only (no custom pattern) -- keeps this a
          // gentle nudge rather than the insistent pattern the discipline
          // protocol's task alerts use, while still not being silent.
          enableVibration: true,
          audioAttributesUsage: AudioAttributesUsage.notificationRingtone,
          category: AndroidNotificationCategory.reminder,
        ),
        iOS: const DarwinNotificationDetails(presentSound: true),
      ),
    );
  }

  static Future<void> scheduleCoachCommandNotifications({
    required List<String> commands,
    String? predictedRiskWindow,
    int? maxNotifications,
    int spacingMinutes = 20,
  }) async {
    if (commands.isEmpty) {
      return;
    }

    final scheduleMode = await _resolveAndroidScheduleMode();
    final code = await LanguageService.loadSelectedLanguageCode();
    final now = tz.TZDateTime.now(tz.local);
    final windowStart = _parseWindowStart(predictedRiskWindow);

    var base = _atDeviceTimeOfDay(
      windowStart?.hour ?? now.hour,
      windowStart?.minute ?? now.minute,
    );
    if (!base.isAfter(now)) {
      base = base.add(const Duration(days: 1));
    }

    final firstAt = base.subtract(const Duration(minutes: 30));
    final normalizedFirstAt = firstAt.isAfter(now)
        ? firstAt
        : now.add(const Duration(minutes: 2));
    final interruptionContext = await _resolveInterruptionContext();
    final extraDelay =
        (interruptionContext['recommendedDeferralMinutes'] as int?) ?? 0;
    final contextLabel =
        interruptionContext['contextLabel']?.toString() ?? 'normal';
    final confidence =
        (interruptionContext['confidence'] as num?)?.toDouble() ?? 0.0;
    await _persistNotificationContext(
      code: code,
      contextLabel: contextLabel,
      confidence: confidence,
    );

    final safeSpacing = spacingMinutes < 10 ? 10 : spacingMinutes;
    final configuredMax = (maxNotifications ?? 3).clamp(1, 6);
    final maxCount = commands.length < configuredMax
        ? commands.length
        : configuredMax;
    for (var i = 0; i < maxCount; i++) {
      final fireAt = await _reserveNonConflictingTime(
        normalizedFirstAt
            .add(Duration(minutes: i * safeSpacing))
            .add(Duration(minutes: extraDelay)),
      );
      // A coaching line is offered, not owed: it competes for the same daily
      // slots as the health tip, the breath reminder and the sedentary
      // nudge, and yields to any of them still waiting for one.
      if (!await _budgetAllows(
        NotificationKind.coachCommand,
        at: fireAt,
        lowestPendingOfferedPriority: const NotificationBudget().priorityOf(
          NotificationKind.coachCommand,
        ),
      )) {
        continue;
      }
      final id = (DateTime.now().millisecondsSinceEpoch + 700000 + i).remainder(
        2147483647,
      );

      await _plugin.zonedSchedule(
        id,
        _text(code, 'coachCommandTitle'),
        AppTexts.localizeCanonicalTextForCode(code, commands[i]),
        fireAt,
        NotificationDetails(
          android: AndroidNotificationDetails(
            // A different channel from task alerts on purpose. A coaching
            // line is offered, a task is owed, and using the same alarm
            // sound and full-screen intent for both made every notification
            // in the app look and feel like the one most urgent kind.
            _coachCommandChannelId,
            _text(code, 'channelNameCoachSuggestion'),
            importance: Importance.defaultImportance,
            visibility: NotificationVisibility.private,
            priority: Priority.defaultPriority,
            playSound: true,
            enableVibration: true,
            category: AndroidNotificationCategory.reminder,
          ),
          iOS: const DarwinNotificationDetails(
            categoryIdentifier: _categoryTaskStart,
            presentSound: true,
          ),
        ),
        androidScheduleMode: scheduleMode,
        uiLocalNotificationDateInterpretation:
            UILocalNotificationDateInterpretation.absoluteTime,
        payload: jsonEncode({
          'type': _typeCoachCommand,
          'taskTitle': commands[i],
        }),
      );
    }
  }

  /// Shared cross-scheduler collision avoidance. Health tips, breath
  /// reminders, coach commands, the weekly-survey-due reminder, and
  /// deferred ("not now") task triggers are each scheduled by independent
  /// code paths with no visibility into what the others already scheduled
  /// -- each one already spaces its *own* notifications apart internally,
  /// but nothing previously stopped e.g. a health tip and a breath reminder
  /// from landing in the same minute, which is exactly the "notifications
  /// arrive back to back" complaint a single scheduler's internal spacing
  /// can't fix on its own. This nudges [proposed] forward in [minGap] steps
  /// until it's at least [minGap] from every other still-pending
  /// reservation, then records it so later calls (including from other
  /// scheduler functions) see it too. Deliberately NOT used for medication
  /// reminders (the user chose those exact times for a reason) or the
  /// immediate/urgent task-trigger alerts (those must fire on their own
  /// timing, never pushed later to dodge a reminder).
  /// The one gate every notification passes through.
  ///
  /// Returns false when this one should not be sent. Fifteen schedulers used
  /// to decide for themselves and only three consulted the shared spacing
  /// helper, so each looked correct alone while the person holding the phone
  /// heard from six unrelated code paths in a row. Nothing counted the total
  /// and nothing chose what to drop once the day was full.
  ///
  /// Scheduled notifications are counted when they are scheduled, not when
  /// they fire: the app may not be running at that moment, so there is no
  /// later opportunity to ask.
  static Future<bool> _budgetAllows(
    NotificationKind kind, {
    DateTime? at,
    int lowestPendingOfferedPriority = 99,
  }) async {
    try {
      const budget = NotificationBudget();
      final storage = StorageService();

      // Checked before spending anything from the budget: a kind the user
      // switched off in Settings should not also use up a slot another,
      // wanted kind could have had today.
      if (budget.classOf(kind) == NotificationClass.offered &&
          !await storage.isNotificationKindEnabled(kind.name)) {
        return false;
      }

      final when = at ?? DateTime.now();
      final (sentToday, lastSentAt) = await storage.loadNotificationBudgetState(
        now: when,
      );
      final decision = budget.decide(
        kind: kind,
        at: when,
        intensity: await storage.loadInterventionIntensity(),
        offeredSentToday: sentToday,
        lastSentAt: lastSentAt,
        lowestPendingOfferedPriority: lowestPendingOfferedPriority,
      );
      if (!decision.allowed) {
        return false;
      }
      await storage.recordNotificationSent(
        countsAgainstBudget: budget.classOf(kind) == NotificationClass.offered,
        at: when,
      );
      return true;
    } catch (_) {
      // A failure here must never silence a task the user is owed.
      return true;
    }
  }

  static Future<tz.TZDateTime> _reserveNonConflictingTime(
    tz.TZDateTime proposed, {
    Duration minGap = const Duration(minutes: 25),
  }) async {
    try {
      final storage = StorageService();
      final now = DateTime.now().millisecondsSinceEpoch;
      final raw = await storage.loadSetting(_reservedTimesSettingKey);
      var reserved = <int>[];
      if (raw != null && raw.isNotEmpty) {
        reserved = (jsonDecode(raw) as List)
            .whereType<num>()
            .map((n) => n.toInt())
            .where((millis) => millis > now)
            .toList();
      }

      var candidate = proposed;
      var guard = 0;
      while (guard < 48 &&
          reserved.any(
            (millis) =>
                (candidate.millisecondsSinceEpoch - millis).abs() <
                minGap.inMilliseconds,
          )) {
        candidate = candidate.add(minGap);
        guard++;
      }

      reserved.add(candidate.millisecondsSinceEpoch);
      await storage.saveSetting(_reservedTimesSettingKey, jsonEncode(reserved));
      return candidate;
    } catch (_) {
      return proposed;
    }
  }

  static Future<Map<String, dynamic>> _resolveInterruptionContext() async {
    try {
      return await PhoneStateService().inferRealtimeInterruptionContext();
    } catch (_) {
      return {
        'isDriving': false,
        'isRunningOrWorkout': false,
        'isEatingLikely': false,
        'recommendedDeferralMinutes': 0,
        'confidence': 0.0,
        'contextLabel': 'normal',
      };
    }
  }

  static Future<void> _persistNotificationContext({
    required String code,
    required String contextLabel,
    required double confidence,
  }) async {
    try {
      final storage = StorageService();
      final confidencePct = (confidence * 100).round().clamp(0, 100);
      await storage.saveSetting(
        'last_notification_context_label',
        contextLabel,
      );
      await storage.saveSetting(
        'last_notification_context_confidence',
        confidencePct.toString(),
      );
      await storage.saveSetting(
        'last_notification_context_reason',
        _contextReasonText(code, contextLabel, confidencePct),
      );
    } catch (_) {
      // Best effort only.
    }
  }

  static String _contextReasonText(
    String code,
    String contextLabel,
    int confidencePct,
  ) {
    if (contextLabel == 'driving') {
      return '${_text(code, 'contextReasonDriving')} (%$confidencePct)';
    }
    if (contextLabel == 'workout') {
      return '${_text(code, 'contextReasonWorkout')} (%$confidencePct)';
    }
    if (contextLabel == 'eating') {
      return '${_text(code, 'contextReasonEating')} (%$confidencePct)';
    }
    return _text(code, 'contextReasonNormal');
  }

  static DateTime? _parseWindowStart(String? predictedRiskWindow) {
    if (predictedRiskWindow == null || predictedRiskWindow.trim().isEmpty) {
      return null;
    }

    final first = predictedRiskWindow.split('-').first.trim();
    final parts = first.split(':');
    if (parts.length != 2) {
      return null;
    }

    final hour = int.tryParse(parts[0]);
    final minute = int.tryParse(parts[1]);
    if (hour == null || minute == null) {
      return null;
    }

    final now = DateTime.now();
    return DateTime(now.year, now.month, now.day, hour, minute);
  }

  static String _text(String code, String key) {
    return AppTexts.textForCode(code, key);
  }
}
